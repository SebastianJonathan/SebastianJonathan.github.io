export default {
  name: 'button',
};
